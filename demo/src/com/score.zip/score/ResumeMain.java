package com.score;

public class ResumeMain {

	public static void main(String[] args) {
		
		Resume rs = new Resume();
		
		rs.set();
		rs.input();
		rs.total();
		rs.output();

	}

}
