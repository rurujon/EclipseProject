package com.score;

public class Record {
	
	String name;
	int[] score = new int[3];//k,e,m
	int tot,ave,rank;
	

}
