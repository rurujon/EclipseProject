package com.score;

public class ScoreMain {

	public static void main(String[] args) {
		
		Score ob = new Score();
		
		ob.set();
		ob.input();
		ob.print();
		

	}

}
