package com.score;

public class Trecord {
	
	String name, license;
	String cre;
	int age, score;
	int hsc;
	String yn;

}
