package com.day9;

import java.util.Scanner;

public class Exam1 {

	public static void main(String[] args) {
		
		Exam1Test ob = new Exam1Test();
		ob.input();
		ob.score();
		ob.output();

	}

}
