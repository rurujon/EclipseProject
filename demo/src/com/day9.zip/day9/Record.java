package com.day9;

public class Record {
	
	String name;
	int[] score = new int[3];
	String[] grade = new String[3];	

}
