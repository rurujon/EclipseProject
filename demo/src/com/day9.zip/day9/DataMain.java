package com.day9;

public class DataMain {

	public static void main(String[] args) {
		
		//Data ob = new Data();
		//ob.print();
		Data.getInstance();

	}

}
