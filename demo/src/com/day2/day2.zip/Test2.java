package com.day2;

public class Test2 {
	public static void main(String[] args) {
		
		//����
		//�ڷ���
		//= : ���Կ�����
		int a = 10; //���� �ʱ�ȭ
		int b = 5;
		int c, d; //�����Ⱚ
		c=a+b;
		d=a-b;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println(a + "+" + b + "=" + (c));
		System.out.println(a + "-" + b + "=" + (d));
		
		
		a=100;
		b=50;
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		c= a+b;
		d= a-b;
		
		System.out.println(c);
		System.out.println(d);
		
		System.out.printf("%d + %d = %d %n",a,b,c);
		System.out.printf("%d - %d = %d \n",a,b,d);
		
	}

}
