package com.monday;

import java.util.Scanner;

import com.monday.ProductDTO;

public class MondayMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Monday ob = new Monday();
		int ch;
		
		while(true) {
			
			do {
				System.out.println("1.��ǰ 2.������ 3.���� 4.���ų��� 5.������� : ");
				ch=sc.nextInt();
			}
			while(ch<1||ch>7);
			
			switch(ch) {
			
			case 1 : 
				System.out.println("1. ��ü, 2. ��з�");
				int a = sc.nextInt();
				switch(a) {
				
				case 1 : ob.selectAllProduct(); break;
				case 2 : ob.selectPointProduct(); break;
				
				default:
					System.exit(0);
					break;
				}
					
				break;
			case 2 : 
			case 3 : 
			case 4 : 
			case 5 : 
			case 6 : 
				
			default :
				System.exit(0);
				break;
			}
		}

	}

}
