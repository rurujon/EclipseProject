package com.monday;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.monday.ProductDTO;

public class Monday {
	
	Scanner sc = new Scanner(System.in);
	
	MondayDAO dao = new MondayDAO();
	
	//��ü ��ǰ ����Ʈ monday
	public void selectAllProduct() {
		
		List<ProductDTO> lists = dao.getList();
		
		Iterator<ProductDTO> it = lists.iterator();
		
		while(it.hasNext()) {
			
			ProductDTO dto = it.next();
			System.out.println(dto.toString());
		}
	}
	
	public void selectPointProduct() {
		
		ProductDTO dto = new ProductDTO();
		
		List<BigCatalDTO> bigCatalLists = dao.bigCatalList();
		
		Iterator<BigCatalDTO> bigCatalIt = bigCatalLists.iterator();
		
		while(bigCatalIt.hasNext()) {
			
			BigCatalDTO bigDto = bigCatalIt.next();
			System.out.println(bigDto.toString());
		}
		
		System.out.println("��з��� �����Ͻÿ�.(�ѱ۷� �Է��ϼ���)");
		
		
		dto.setSearchCatal(sc.next());
		
		System.out.println(dto.getSearchCatal());
		
		System.out.println("�̴�� �˻��Ͻðڽ��ϱ�?");
		System.out.println("1.��, 2.�Һз���");
		
		int b=sc.nextInt();
		
		switch(b) {
		
		case 1 :
			List<ProductDTO> bigLists = dao.getBigList(dto);

			Iterator<ProductDTO> bigIt = bigLists.iterator();

			while(bigIt.hasNext()) {

				dto = bigIt.next();
				System.out.println(dto.toString());
			}
			
		case 2 :
			
			List<SmallCatalDTO> smallCatalLists = dao.smallCatalList();
			
			Iterator<SmallCatalDTO> smallCatalIt = smallCatalLists.iterator();
			
			while(smallCatalIt.hasNext()) {
				
				SmallCatalDTO smallDto = smallCatalIt.next();
				System.out.println(smallDto.toString());
			}
			
			
			System.out.println("�Һз��� �����ϼ��� (�ѱ۷� �Է��ϼ���)");
			dto.setSearchCatal(sc.next());
			List<ProductDTO> smallLists = dao.getSmallList(dto);

			Iterator<ProductDTO> smallIt = smallLists.iterator();

			while(smallIt.hasNext()) {

				dto = smallIt.next();
				System.out.println(dto.toString());
			}
			
		}
		
	}

}
