package com.day7;

public class D1t2test {

	public static void main(String[] args) {
		
		D1t2 dt = new D1t2();
		dt.input();
		int a=dt.max();
		int b=dt.min();
		dt.output(a, b);

	}

}
