package com.day7;

public class AllSumTest {

	public static void main(String[] args) {
		
		Allsum su = new Allsum();
		su.input();
		int a=su.Calc();
		su.output(a);
		

	}

}
