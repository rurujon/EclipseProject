package com.day7;

public class Mult3Test {

	public static void main(String[] args) {
		
		Mult3 mu = new Mult3();
		mu.input();
		int k = mu.calc();
		mu.output(k);

	}

}
