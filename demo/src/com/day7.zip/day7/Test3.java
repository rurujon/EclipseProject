package com.day7;

public class Test3 {

	public static void main(String[] args) {
		
		Hap h = new Hap();
		
		h.input();
		int tot = h.cnt();
		
		h.print(tot);

	}

}
