package com.day7;

public class D1t1test {

	public static void main(String[] args) {
		
		D1t1 dt = new D1t1();
		dt.input();
		String b = dt.det();
		dt.output(b);

	}

}
