package com.day7;

import java.io.IOException;

public class CalcTest {

	public static void main(String[] args) throws IOException{
		
		Calc ca = new Calc();
		
		ca.input();
		ca.output();

	}

}
