package com.score1;

public class Record {
	
	String hak, name;
	int kor, eng, mat;
	int tot, ave;

}
