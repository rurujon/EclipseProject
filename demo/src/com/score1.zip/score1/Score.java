package com.score1;

public interface Score {
	
	public void set();
	public void input();
	public void print();

}
