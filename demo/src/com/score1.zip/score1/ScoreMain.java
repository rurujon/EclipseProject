package com.score1;

public class ScoreMain {

	public static void main(String[] args) {
		
		Score ob = new ScoreImpl();
		
		ob.set();
		ob.input();
		ob.print();

	}

}
