package com.naver;

public interface Naver {
	
	public void input();
	public void print();
	public void searchId();
	public void searchPassword();
	public void delete();
	public void change();

}
