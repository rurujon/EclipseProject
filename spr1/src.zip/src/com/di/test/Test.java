package com.di.test;

public interface Test {
	
	public String result();

}
